﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();

            List<IEntity> collection = new List<IEntity>();

            while (input != "End")
            {
                string[] split = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (split.Length == 3)
                {
                    IEntity human = new Human(split[0], int.Parse(split[1]), split[2]);
                    collection.Add(human);
                }
                else if (split.Length == 2)
                {
                    IEntity robot = new Robot(split[0], split[1]);
                    collection.Add(robot);
                }
                

                input = Console.ReadLine();
            }

            string number = Console.ReadLine();

            foreach (IEntity entity in collection)
            {
                if (entity.Filtering(number))
                {
                    Console.WriteLine(entity.Id);
                }
            }
        }
    }
}
