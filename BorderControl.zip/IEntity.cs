﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IEntity
    {
        string Id { get; set; }

        bool Filtering(string number);
    }
}
