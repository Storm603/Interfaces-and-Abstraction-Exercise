﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Human : IEntity, IBirthable, IBuyer
    {
        public Human(string name, int age, string id, string birthdate)
        {
            Name = name;
            Age = age;
            Id = id;
            Birthdate = birthdate;
            Food = 0;
        }
        public string Name { get; private set; }
        public int Age { get; set; }
        public string Id { get; set; }
        public string Birthdate { get; set; }

        public bool Filtering(string number)
        {
            if (Birthdate.EndsWith(number))
            {
                return true;
            }

            return false;
        }

        public int Food { get; private set; }
        public void BuyFood()
        {
            Food += 10;
        }
    }
}
