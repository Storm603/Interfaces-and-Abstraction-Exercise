﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace BorderControl
{
    public class Program
    {
        static void Main(string[] args)
        {
            int peopleCount = int.Parse(Console.ReadLine());

            List<IBuyer> collection = new List<IBuyer>();

            for (int i = 0; i < peopleCount; i++)
            {
                string[] split = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                IBuyer entity;
                if (split.Length == 3)
                {
                    entity = new Rebel(split[0], int.Parse(split[1]), split[2]);
                    collection.Add(entity);
                }
                else if (split.Length == 4)
                {
                    entity = new Human(split[0], int.Parse(split[1]), split[2], split[3]);
                    collection.Add(entity);
                }
            }

            string input = Console.ReadLine();


            while (input != "End")
            {
                IBuyer name = collection.FirstOrDefault(x => x.Name == input);

                if (name != null)
                {
                    name.BuyFood();
                }
                
                input = Console.ReadLine();
            }

            Console.WriteLine(collection.Sum(x => x.Food));
        }
    }
}
